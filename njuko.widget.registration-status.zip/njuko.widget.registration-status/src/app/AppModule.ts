import {NgModule} from "@angular/core";
import {DynamicComponentLoaderModule} from "@workspace/dynamic-component-loader/dynamic-component-load.module";
import {SharedModule} from "@workspace/shared";
import {AppRoutingModule} from "./AppRoutingModule";
import {AppRoutingModuleFront} from "./AppRoutingModuleFront";
import { DisplayBack } from './components/back/DisplayBack';
import { DisplayFront } from './components/front/DisplayFront';
import { Edit } from './components/back/Edit';
import { UploadFile } from './components/front/UploadFile';
import { RegistrationsService } from '../../../../../libs/registrations/src/services/registrations.service';

@NgModule({
    declarations: [
      DisplayBack,
      Edit
    ],
    imports: [
      SharedModule,
      AppRoutingModule,
      DynamicComponentLoaderModule.forChild(DisplayBack),
      DynamicComponentLoaderModule.forChild(Edit)
    ],
    entryComponents: [],
    providers: []
})
export class AppModule {

}

@NgModule({
    declarations: [
      DisplayFront,
      UploadFile
    ],
    imports: [
        SharedModule,
        AppRoutingModuleFront,
        DynamicComponentLoaderModule.forChild(DisplayFront),
        DynamicComponentLoaderModule.forChild(UploadFile)
    ],
    entryComponents: [],
    providers: [
        RegistrationsService
    ]
})
export class AppModuleFront {

}
