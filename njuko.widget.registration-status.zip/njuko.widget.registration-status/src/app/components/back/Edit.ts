import { Component, Input, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'Edit',
  templateUrl: './edit.html',
  styleUrls:  ['./edit.scss']
})
export class Edit implements OnInit, OnDestroy {

  @Input('data') data: any;

  constructor() {}

  ngOnInit(): void {}

  ngOnDestroy(): void {}
}
