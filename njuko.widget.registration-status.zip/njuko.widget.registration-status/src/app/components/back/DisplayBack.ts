import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { RegistrationsService } from '../../../../../../../libs/registrations/src/services/registrations.service';
import { componentDestroyed } from '../../../../../../../libs/njukore/src/utils/component-destroyed';
import { I18nService } from '../../../../../../../libs/i18n';
import { Registration } from '../../../../../../../libs/models/Registration';
import { Tag } from '../../../../../../../libs/models/Tag';

@Component({
  selector: 'DisplayBack',
  templateUrl: './displayBack.html',
  styleUrls:  ['./displayBack.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DisplayBack implements OnInit, OnDestroy {

  @Input('data') data: any;

  registration: any;
  loading = false;
  status: Tag;

  constructor(
      private registrationsService: RegistrationsService,
      private translateService: I18nService,
      private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loading = true;
    this.registrationsService
      .getRegistrationForWidget(this.data.edition._id)
      .takeUntil(componentDestroyed(this))
      .subscribe(registration => {
        if (registration) {
          this.registration = registration;
          this.status = this.getStatusForRegistration(registration);
        }
        this.loading = false;
        this.cd.markForCheck();
      });
  }

  ngOnDestroy(): void {}

  private getStatusForRegistration(registration: Registration): Tag {
    const object = registration.tags.find(object =>
      object.tag.category && object.tag.category.role === 'registration_status'
    );
    return object ? object.tag : null;
  }
}
