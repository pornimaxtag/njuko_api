import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { I18nService } from '@workspace/i18n';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { UploadFile } from './UploadFile';
import { RegistrationsService } from '../../../../../../../libs/registrations/src/services/registrations.service';
import { Registration } from '../../../../../../../libs/models/Registration';
import { Tag } from '../../../../../../../libs/models/Tag';

@Component({
  selector: 'DisplayFront',
  templateUrl: './displayFront.html',
  styleUrls:  ['./displayFront.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DisplayFront implements OnInit, OnDestroy {

  teamDashboard = null;
  status = [
    "PendingValidation",
    "Rejected",
    "Accepted"
  ];

  @Input('data') data: any;
  registration: any = null;
  registrationStatus: Tag;

  constructor(
      private registrationsService: RegistrationsService,
      public translateService: I18nService,
      public router: Router,
      public dialog: MatDialog,
      private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.registration = JSON.parse(JSON.stringify(this.data.registration));
    this.registrationsService.getRegistrationForWidgetFront(this.registration._id).subscribe(registration => {
      this.registration = registration;
      this.registrationStatus = this.getStatusForRegistration(registration);
    });
  }

  ngOnDestroy(): void {}

  private getStatusForRegistration(registration: Registration): Tag {
    const object = registration.tags.find(object =>
      object.tag.category && object.tag.category.role === 'registration_status'
    );
    return object ? object.tag : null;
  }

  gotoTeamDashboard(): void {
    this.router.navigate(['reservation/' + this.data.registration.edition.url + '/team-dashboard']);
  }

  downloadFile(file: string): void {
    window.open(file);
  }

  addFile(id: string): void {
    const dialog = this.dialog.open(UploadFile, {
      data: {
        answerId: id,
        registration: this.data.registration
      },
      minWidth: '500px'
    });

    dialog.afterClosed().subscribe(result => {
      if (result) {
        this.registrationsService.editAnswerFromFront(
            {
              id: id,
              registration: this.data.registration
            },
            {
              status: 'PendingValidation',
              value: result
            }).subscribe(response => {
          const answers = [];
          this.registration.answers.forEach(answer => {
            if (answer._id === response._id) {
              answers.push(response);
            } else {
              answers.push(answer);
            }
          });
          this.registration.answers = answers;
          this.cd.markForCheck();
        });
      }
    });
  }
}
