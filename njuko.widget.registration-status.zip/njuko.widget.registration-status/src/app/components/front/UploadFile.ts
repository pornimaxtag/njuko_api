import { ChangeDetectorRef, Component, Inject, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CustomConfig } from '../../../../../../../libs/environments/src/config/CustomConfig';

@Component({
  selector: 'UploadFile',
  templateUrl: './uploadFile.html',
  styleUrls:  ['./uploadFile.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UploadFile implements OnInit, OnDestroy {

  uploadUrl: string;
  fileUrl: string;

  @ViewChild('fileUploadQueue', { static: true }) fileUploadQueue;

  constructor(
    public dialogRef: MatDialogRef<UploadFile>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    @Inject('config') private config: CustomConfig
  ) {}

  ngOnInit(): void {
    const reservation = this.data.registration.reservation;
    this.uploadUrl = this.config.apiFrontUrl + 'registration/upload/' + reservation._id + '/' + reservation.token;
  }

  ngOnDestroy(): void {}

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(this.fileUrl);
  }

  onFileUploaded(event) {
    if (event.event.body) {
      this.fileUrl = event.event.body.data.Location;
    }
  }

  onFileRemoved(event) {

  }

  onError(error) {
    setTimeout(() => {

    });
  }
}
